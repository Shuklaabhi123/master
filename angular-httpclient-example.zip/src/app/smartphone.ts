export interface Smartphone {
  id: string;
  name: string;
  desc: string;
  price: number;
  updated: Date;
}
